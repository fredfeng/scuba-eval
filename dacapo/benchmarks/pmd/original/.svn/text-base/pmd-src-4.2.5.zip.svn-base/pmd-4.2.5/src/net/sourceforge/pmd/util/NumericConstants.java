package net.sourceforge.pmd.util;

public interface NumericConstants {

	Integer ZERO	= 0;
	Integer ONE		= 1;
}
