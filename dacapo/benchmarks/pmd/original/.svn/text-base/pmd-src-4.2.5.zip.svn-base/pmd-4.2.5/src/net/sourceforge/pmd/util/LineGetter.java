package net.sourceforge.pmd.util;

public interface LineGetter {
    String getLine(int number);
}
